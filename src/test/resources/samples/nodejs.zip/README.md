Development
-----------

Installing dependencies: `npm install`

To run tests: `npm test`

To start server: `node server.js`
